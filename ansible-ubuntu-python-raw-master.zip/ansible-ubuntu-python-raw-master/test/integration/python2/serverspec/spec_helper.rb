# Encoding: utf-8
require 'serverspec'

set :backend, :exec